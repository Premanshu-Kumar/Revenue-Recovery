"""
Runs the full batch through the policy engine and produces:
  outputs/audit_trail.csv   -> one row per event with full decision trace
  outputs/metrics.json      -> aggregate money-recovered metrics
  outputs/metrics_by_type.csv -> breakdown by event_type

This is the artifact you show in the demo / pitch video.
"""

import csv
import json
import sys
import os

sys.path.append(os.path.dirname(__file__))
from policy import diagnose, decide, stopping_rule_blocks, simulate_execute

random_seed_note = "Deterministic diagnosis/decision logic; execution outcome uses a seeded RNG (see data/generate_data.py seed) for reproducibility."

def run():
    with open("/home/claude/revenue_recovery/data/events.csv") as f:
        events = list(csv.DictReader(f))

    audit_rows = []
    total_at_risk = 0.0
    total_recovered = 0.0
    escalated_count = 0
    blocked_count = 0

    for ev in events:
        amount = float(ev["amount"])
        total_at_risk += amount

        root_cause = diagnose(ev)
        decision = decide(ev, root_cause)
        blocked, block_reason = stopping_rule_blocks(ev, decision, root_cause)

        if blocked:
            blocked_count += 1
            final_action = "escalate_to_human_review"
            outcome = "escalated"
            amount_recovered = 0.0
            escalated_count += 1
        else:
            result = simulate_execute(ev, decision, root_cause)
            final_action = decision["action"]
            outcome = result["outcome"]
            amount_recovered = result["amount_recovered"]
            if final_action.startswith("escalate"):
                escalated_count += 1
            total_recovered += amount_recovered

        audit_rows.append({
            "event_id": ev["event_id"],
            "event_type": ev["event_type"],
            "customer_id": ev["customer_id"],
            "amount_at_risk": amount,
            "root_cause": root_cause,
            "decided_action": decision["action"],
            "decided_channel": decision["channel"],
            "wait_hours": decision["wait_hours"],
            "stopping_rule_triggered": block_reason if blocked else "",
            "final_action_taken": final_action,
            "outcome": outcome,
            "amount_recovered": amount_recovered,
            "decision_note": decision["note"],
        })

    # Write audit trail
    out_dir = "/home/claude/revenue_recovery/outputs"
    os.makedirs(out_dir, exist_ok=True)
    fields = list(audit_rows[0].keys())
    with open(f"{out_dir}/audit_trail.csv", "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader()
        w.writerows(audit_rows)

    # Aggregate metrics
    metrics = {
        "batch_size": len(events),
        "total_amount_at_risk": round(total_at_risk, 2),
        "total_amount_recovered": round(total_recovered, 2),
        "recovery_rate_pct": round(100 * total_recovered / total_at_risk, 2) if total_at_risk else 0,
        "events_escalated_to_human": escalated_count,
        "events_blocked_by_stopping_rules": blocked_count,
        "note": random_seed_note,
    }
    with open(f"{out_dir}/metrics.json", "w") as f:
        json.dump(metrics, f, indent=2)

    # Breakdown by type
    by_type = {}
    for row in audit_rows:
        t = row["event_type"]
        by_type.setdefault(t, {"count": 0, "at_risk": 0.0, "recovered": 0.0, "escalated": 0})
        by_type[t]["count"] += 1
        by_type[t]["at_risk"] += row["amount_at_risk"]
        by_type[t]["recovered"] += row["amount_recovered"]
        if row["outcome"] == "escalated":
            by_type[t]["escalated"] += 1

    with open(f"{out_dir}/metrics_by_type.csv", "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["event_type", "count", "amount_at_risk", "amount_recovered", "recovery_rate_pct", "escalated_count"])
        for t, v in by_type.items():
            rate = round(100 * v["recovered"] / v["at_risk"], 2) if v["at_risk"] else 0
            w.writerow([t, v["count"], round(v["at_risk"], 2), round(v["recovered"], 2), rate, v["escalated"]])

    print(json.dumps(metrics, indent=2))
    print(f"\nAudit trail: {out_dir}/audit_trail.csv")
    print(f"By-type breakdown: {out_dir}/metrics_by_type.csv")

if __name__ == "__main__":
    run()
