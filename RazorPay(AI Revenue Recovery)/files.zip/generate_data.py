"""
Generates a synthetic batch of "revenue at risk" events covering all four
event families mentioned in the track brief:
  - payment_failure       (card/UPI/netbanking payment declined)
  - checkout_abandonment  (cart created, payment never attempted)
  - subscription_failure  (recurring mandate/auto-debit failed)
  - invoice_overdue       (B2B receivable past due date)

Output: data/events.csv  (~120 rows)
"""

import csv
import random
from datetime import datetime, timedelta

random.seed(42)

PAYMENT_FAILURE_REASONS = [
    "insufficient_funds", "card_expired", "bank_server_timeout",
    "otp_mismatch", "risk_engine_block", "daily_limit_exceeded",
]
CHECKOUT_DROPOFF_STAGES = [
    "otp_screen", "payment_method_select", "address_entry", "review_screen",
]
SUBSCRIPTION_FAILURE_REASONS = [
    "mandate_not_registered", "insufficient_funds", "card_expired",
    "bank_declined_recurring",
]

CUSTOMER_PREF_CHANNEL = ["sms", "whatsapp", "email", "call"]

def rand_ts(days_back_max=14):
    return (datetime.now() - timedelta(
        days=random.randint(0, days_back_max),
        hours=random.randint(0, 23),
    )).isoformat(timespec="minutes")

def gen_payment_failures(n):
    rows = []
    for i in range(n):
        rows.append({
            "event_id": f"PF-{i+1:04d}",
            "event_type": "payment_failure",
            "customer_id": f"CUST-{random.randint(1000,1200)}",
            "amount": round(random.uniform(199, 15000), 2),
            "timestamp": rand_ts(),
            "reason_raw": random.choice(PAYMENT_FAILURE_REASONS),
            "attempts_so_far": random.choice([0, 0, 1, 2]),
            "contact_pref": random.choice(CUSTOMER_PREF_CHANNEL),
            "overdue_days": "",
        })
    return rows

def gen_checkout_abandonment(n):
    rows = []
    for i in range(n):
        rows.append({
            "event_id": f"CA-{i+1:04d}",
            "event_type": "checkout_abandonment",
            "customer_id": f"CUST-{random.randint(1200,1400)}",
            "amount": round(random.uniform(299, 8000), 2),
            "timestamp": rand_ts(),
            "reason_raw": random.choice(CHECKOUT_DROPOFF_STAGES),
            "attempts_so_far": 0,
            "contact_pref": random.choice(CUSTOMER_PREF_CHANNEL),
            "overdue_days": "",
        })
    return rows

def gen_subscription_failures(n):
    rows = []
    for i in range(n):
        rows.append({
            "event_id": f"SF-{i+1:04d}",
            "event_type": "subscription_failure",
            "customer_id": f"CUST-{random.randint(1400,1550)}",
            "amount": round(random.uniform(99, 2499), 2),
            "timestamp": rand_ts(),
            "reason_raw": random.choice(SUBSCRIPTION_FAILURE_REASONS),
            "attempts_so_far": random.choice([0, 1, 2, 3]),
            "contact_pref": random.choice(CUSTOMER_PREF_CHANNEL),
            "overdue_days": "",
        })
    return rows

def gen_invoice_overdue(n):
    rows = []
    for i in range(n):
        rows.append({
            "event_id": f"IN-{i+1:04d}",
            "event_type": "invoice_overdue",
            "customer_id": f"BIZ-{random.randint(1,60)}",
            "amount": round(random.uniform(15000, 500000), 2),
            "timestamp": rand_ts(30),
            "reason_raw": "overdue",
            "attempts_so_far": random.choice([0, 1, 2]),
            "contact_pref": random.choice(["email", "call"]),
            "overdue_days": random.choice([5, 12, 20, 35, 50, 70]),
        })
    return rows

def main():
    rows = (
        gen_payment_failures(40)
        + gen_checkout_abandonment(30)
        + gen_subscription_failures(30)
        + gen_invoice_overdue(20)
    )
    random.shuffle(rows)
    for idx, r in enumerate(rows, start=1):
        r["batch_seq"] = idx

    fields = ["batch_seq", "event_id", "event_type", "customer_id", "amount",
              "timestamp", "reason_raw", "attempts_so_far", "contact_pref",
              "overdue_days"]
    with open("/home/claude/revenue_recovery/data/events.csv", "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader()
        w.writerows(rows)
    print(f"Wrote {len(rows)} events to data/events.csv")

if __name__ == "__main__":
    main()
