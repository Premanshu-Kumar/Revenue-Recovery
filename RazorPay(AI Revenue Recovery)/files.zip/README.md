# Revenue Recovery Agent — Razorpay AI Buildathon, Track 3

A single, bounded policy engine that closes the loop on four kinds of
revenue leakage: **payment failures, checkout abandonment, failed
subscriptions, and overdue B2B invoices** — using one shared
Detect → Diagnose → Decide → Act → Escalate → Audit pipeline instead
of four separate bots.

## Why one engine, not four

Every revenue-loss event has the same underlying shape: something
should have converted, didn't, and needs a *specific, bounded* nudge —
not a generic retry-forever loop. Building one policy engine with
pluggable diagnosis/decision rules per event type:
- proves the *architecture* generalizes (the actual hard part),
- keeps every action auditable and swappable for a real ML classifier
  later without touching the execution/compliance layer,
- lets stopping rules and escalation logic be enforced **once**,
  centrally, instead of re-implemented (and potentially forgotten) in
  each bot.

## Pipeline

```
data/generate_data.py       → synthetic batch of 120 revenue-at-risk events
                                (40 payment failures, 30 checkout
                                abandonments, 30 subscription failures,
                                20 overdue invoices)
        │
        ▼
agent/policy.py
   diagnose(event)           → rule-based root cause (auditable, not a black box)
   decide(event, root_cause) → ONE bounded intervention (never "retry forever")
   stopping_rule_blocks()    → hard compliance limits that override any decision
   simulate_execute()        → mock action outcome (swap for real Razorpay
                                test-mode APIs — see "Going to production" below)
        │
        ▼
agent/run_batch.py           → runs all 120 events through the loop, writes:
   outputs/audit_trail.csv      one row per event: reason → decision → outcome
   outputs/metrics.json         batch-level ₹ recovered, recovery rate
   outputs/metrics_by_type.csv  breakdown per event type
```

## The bar, mapped

| Requirement | Where it's satisfied |
|---|---|
| Detect revenue at risk | `data/events.csv` batch (4 event types) |
| Root-cause diagnosis | `policy.diagnose()` — transparent rule table per event type |
| Right intervention | `policy.decide()` — different root causes get different actions (retry vs. nudge vs. escalate vs. payment plan) |
| Bounded execution | `MAX_PAYMENT_RETRIES`, `MAX_NUDGES`, `MAX_INVOICE_ESCALATION_DAYS`, hard-decline list in `policy.py` |
| Measured money recovered, on a batch | `outputs/metrics.json` — ₹ at risk vs. ₹ recovered vs. recovery rate, computed over all 120 events, not a cherry-picked one |
| Compliant escalation | Risk-flagged declines and invoices beyond 60 days never get auto-actioned — they're routed to `escalate_to_human_review` / `escalate_to_human_collections` |
| Stopping rules | `stopping_rule_blocks()` runs after every decision and can override it |
| Audit trail | `outputs/audit_trail.csv` — every event's reason, decision, channel, and outcome, one row each |

## Sample result (this batch)

- 120 events, ₹58.3L at risk
- ₹22.7L recovered (≈38.9% recovery rate)
- 14 events escalated to a human
- 7 events blocked outright by stopping rules (never auto-actioned)

Recovery probabilities in `simulate_execute()` are intentionally *not*
tuned to look impressive — they vary by how well-matched the
intervention is to the diagnosed cause, so the number is honest rather
than rigged.

## Going to production (what you say in the pitch, don't over-build today)

- Swap `simulate_execute()` for real calls: Razorpay test-mode
  **retry payment** / **create payment link** APIs for payment &
  subscription flows, and a WhatsApp/SMS/email provider for nudges.
- Swap the rule-based `diagnose()` with an ML classifier trained on
  real failure-code distributions once you have labeled data — the
  rest of the pipeline (decide/stop/audit) doesn't need to change.
- Add real quiet-hours enforcement (currently modeled as a constant,
  not enforced against wall-clock time since this runs as an offline batch).

## Run it

```bash
python3 data/generate_data.py
python3 agent/run_batch.py
```
