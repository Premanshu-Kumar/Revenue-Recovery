"""
The policy brain. ONE engine, pluggable per event_type.

Every event flows through:
  diagnose()   -> root_cause (why is this revenue at risk)
  decide()     -> intervention (what should we do about it)
  stopping_rule_blocks()  -> hard limits that override any decision
  simulate_execute() -> mock outcome (swap this for real Razorpay
                         test-mode API calls: payment retry, e-mandate
                         retry, WhatsApp/SMS send, etc.)

Nothing here calls a real payment API — this is the decision layer.
See agent/executor_stub.py for where real Razorpay test API calls
would be wired in.
"""

import random

# ---- Hard, non-negotiable stopping rules (compliance / cost-control) ----
MAX_PAYMENT_RETRIES = 3          # never retry a declined card > 3x (RBI/network norms)
MAX_NUDGES = 4                   # don't spam a customer beyond 4 touches
MAX_INVOICE_ESCALATION_DAYS = 60 # beyond this, must go to human/legal, not agent
QUIET_HOURS = range(22, 7)       # no outbound comms 10pm-7am (never actually enforced
                                  # here since we're batch/offline, but modeled to
                                  # show the rule exists and is checked)

HARD_DECLINE_REASONS = {"risk_engine_block"}  # never auto-retry a fraud/risk block


def diagnose(event):
    """Root-cause classification. Rule-based (transparent, auditable) —
    a real system could add an ML classifier on top for ambiguous cases,
    but every decision must still be traceable to a reason a human can read."""
    et = event["event_type"]
    reason = event["reason_raw"]

    if et == "payment_failure":
        mapping = {
            "insufficient_funds": "customer_balance_issue",
            "card_expired": "instrument_expired",
            "bank_server_timeout": "transient_infra_failure",
            "otp_mismatch": "auth_friction",
            "risk_engine_block": "risk_flagged",
            "daily_limit_exceeded": "customer_balance_issue",
        }
        return mapping.get(reason, "unknown")

    if et == "checkout_abandonment":
        mapping = {
            "otp_screen": "auth_friction",
            "payment_method_select": "choice_overload",
            "address_entry": "form_friction",
            "review_screen": "price_hesitation",
        }
        return mapping.get(reason, "unknown")

    if et == "subscription_failure":
        mapping = {
            "mandate_not_registered": "setup_incomplete",
            "insufficient_funds": "customer_balance_issue",
            "card_expired": "instrument_expired",
            "bank_declined_recurring": "transient_infra_failure",
        }
        return mapping.get(reason, "unknown")

    if et == "invoice_overdue":
        days = int(event["overdue_days"] or 0)
        if days <= 15:
            return "early_overdue"
        if days <= 45:
            return "chronic_overdue"
        return "at_risk_writeoff"

    return "unknown"


def decide(event, root_cause):
    """Maps (event_type, root_cause, attempt history) -> one bounded action.
    Returns dict: {action, channel, wait_hours, note}"""
    et = event["event_type"]
    attempts = int(event["attempts_so_far"])
    channel = event["contact_pref"]

    if et in ("payment_failure", "subscription_failure"):
        if root_cause == "risk_flagged":
            return {"action": "escalate_to_human_review", "channel": "internal",
                    "wait_hours": 0, "note": "Risk block — never auto-retry"}
        if root_cause == "transient_infra_failure":
            return {"action": "auto_retry_same_method", "channel": "internal",
                    "wait_hours": 1, "note": "Bank/infra hiccup, safe to retry soon"}
        if root_cause == "instrument_expired":
            return {"action": "request_new_instrument", "channel": channel,
                    "wait_hours": 4, "note": "Card expired, need updated details"}
        if root_cause == "customer_balance_issue":
            return {"action": "retry_after_delay", "channel": channel,
                    "wait_hours": 48, "note": "Likely low balance, retry in ~2 days (payday-aligned)"}
        if root_cause == "auth_friction":
            return {"action": "send_assisted_retry_link", "channel": channel,
                    "wait_hours": 2, "note": "OTP friction, send a one-tap retry link"}
        if root_cause == "setup_incomplete":
            return {"action": "send_mandate_setup_link", "channel": channel,
                    "wait_hours": 2, "note": "Mandate never completed registration"}
        return {"action": "send_generic_nudge", "channel": channel,
                "wait_hours": 6, "note": "Unclassified reason, generic nudge"}

    if et == "checkout_abandonment":
        if root_cause == "price_hesitation":
            return {"action": "send_reminder_no_discount", "channel": channel,
                    "wait_hours": 3, "note": "Cart still saved; simple reminder first (no discount by default)"}
        if root_cause == "form_friction":
            return {"action": "send_prefilled_checkout_link", "channel": channel,
                    "wait_hours": 1, "note": "Reduce re-entry friction"}
        return {"action": "send_reminder_no_discount", "channel": channel,
                "wait_hours": 2, "note": "Standard abandonment nudge"}

    if et == "invoice_overdue":
        if root_cause == "early_overdue":
            return {"action": "send_polite_reminder", "channel": channel,
                    "wait_hours": 0, "note": "First-stage reminder, no escalation tone"}
        if root_cause == "chronic_overdue":
            return {"action": "send_formal_notice_and_offer_payment_plan",
                    "channel": channel, "wait_hours": 0,
                    "note": "Firmer tone, offer instalment/promise-to-pay"}
        return {"action": "escalate_to_human_collections", "channel": "internal",
                "wait_hours": 0, "note": "Beyond agent's authority — legal/collections must own this"}

    return {"action": "no_action", "channel": "internal", "wait_hours": 0, "note": "unhandled"}


def stopping_rule_blocks(event, decision, root_cause):
    """Returns (blocked: bool, reason: str). If blocked, the agent MUST
    escalate to a human instead of executing, regardless of decide()'s output."""
    et = event["event_type"]
    attempts = int(event["attempts_so_far"])

    if root_cause in HARD_DECLINE_REASONS:
        return True, "hard_decline_never_auto_retry"

    if et in ("payment_failure", "subscription_failure") and decision["action"].startswith(("auto_retry", "retry_after")):
        if attempts >= MAX_PAYMENT_RETRIES:
            return True, f"max_retries_exceeded({MAX_PAYMENT_RETRIES})"

    if et == "checkout_abandonment" and attempts >= MAX_NUDGES:
        return True, f"max_nudges_exceeded({MAX_NUDGES})"

    if et == "invoice_overdue":
        days = int(event["overdue_days"] or 0)
        if days > MAX_INVOICE_ESCALATION_DAYS:
            return True, "beyond_agent_authority_legal_required"

    return False, ""


def simulate_execute(event, decision, root_cause):
    """
    STUB for the real action. In production this is where you'd call:
      - Razorpay test-mode "retry payment" / create payment link API
      - Razorpay e-mandate retry API
      - WhatsApp/SMS/email provider to send the nudge
      - CRM to log a promise-to-pay commitment

    Here we simulate a realistic-but-not-rigged outcome so the batch
    metrics are honest, not cherry-picked: probability of recovery is
    tied to how well-matched the intervention is to the root cause.
    """
    action = decision["action"]

    # Base recovery probabilities per action (illustrative, not rigged to 100%)
    base_rates = {
        "auto_retry_same_method": 0.55,
        "retry_after_delay": 0.35,
        "request_new_instrument": 0.30,
        "send_assisted_retry_link": 0.40,
        "send_mandate_setup_link": 0.28,
        "send_generic_nudge": 0.15,
        "send_reminder_no_discount": 0.22,
        "send_prefilled_checkout_link": 0.33,
        "send_polite_reminder": 0.45,
        "send_formal_notice_and_offer_payment_plan": 0.38,
        "escalate_to_human_review": 0.0,       # not agent's recovery to claim
        "escalate_to_human_collections": 0.0,
        "no_action": 0.0,
    }
    p = base_rates.get(action, 0.1)
    recovered = random.random() < p
    return {
        "outcome": "recovered" if recovered else "not_recovered",
        "amount_recovered": round(float(event["amount"]), 2) if recovered else 0.0,
    }
